let accountButton = document.querySelector(".img-button");
let profileContainer = document.querySelector(".accout-profile");

accountButton.addEventListener("click", function() {
    console.log("da")
 profileContainer.classList.toggle("loggedOpen");
 
})